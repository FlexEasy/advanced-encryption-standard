/************************************************************************
Lab 9 Nios Software

Dong Kai Wang, Fall 2017
Christine Chen, Fall 2013

For use with ECE 385 Experiment 9
University of Illinois ECE Department
************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "aes.h"

// Pointer to base address of AES module, make sure it matches Qsys
volatile unsigned int * AES_PTR = (unsigned int *) 0x00000200;

// Execution mode: 0 for testing, 1 for benchmarking
int run_mode = 0;

/** charToHex
 *  Convert a single character to the 4-bit value it represents.
 *  
 *  Input: a character c (e.g. 'A')
 *  Output: converted 4-bit value (e.g. 0xA)
 */
char charToHex(char c)
{
	char hex = c;

	if (hex >= '0' && hex <= '9')
		hex -= '0';
	else if (hex >= 'A' && hex <= 'F')
	{
		hex -= 'A';
		hex += 10;
	}
	else if (hex >= 'a' && hex <= 'f')
	{
		hex -= 'a';
		hex += 10;
	}
	return hex;
}

/** charsToHex
 *  Convert two characters to byte value it represents.
 *  Inputs must be 0-9, A-F, or a-f.
 *  
 *  Input: two characters c1 and c2 (e.g. 'A' and '7')
 *  Output: converted byte value (e.g. 0xA7)
 */
char charsToHex(char c1, char c2)
{
	char hex1 = charToHex(c1);
	char hex2 = charToHex(c2);
	return (hex1 << 4) + hex2;
}




void KeyExpansion(unsigned char * Cipherkey,unsigned char * temp)
{
	//unsigned char * temp = malloc(sizeof(unsigned char * [176]));
	int i,j;
	for(i=0;i<16;i++)
	{
		temp[i] = Cipherkey[i];
	}
	
	
	//
	//temp1 = Cipherkey{}
	
	//
	
	//unsigned int w_temp;
	//unsigned char temp;
	//w_temp = SubBytes(RotWord(w_temp)) ^ Rcon
	for(i=1;i<11;i++)
	{
		/*temp[16] = aes_sbox[temp[7]] ^ Rcon[1];
		temp[20] = aes_sbox[temp[11]] ^ (Rcon[1] >> 4);
		temp[24] = aes_sbox[temp[15]] ^ (Rcon[1] >> 8);
		temp[28] = aes_sbox[temp[3]] ^ (Rcon[1] >> 12);*/
		temp[i*16] = aes_sbox[temp[(i-1)*16+7]] ^ (Rcon[i]>>24);
		temp[i*16+4] = aes_sbox[temp[(i-1)*16+11]] ^ (Rcon[i]>>16);
		temp[i*16+8] = aes_sbox[temp[(i-1)*16+15]] ^ (Rcon[i]>>8);
		temp[i*16+12] = aes_sbox[temp[(i-1)*16+3]] ^ Rcon[i];
		temp[i*16] = temp[i*16] ^ temp[(i-1)*16];
		temp[i*16+4] = temp[i*16+4] ^ temp[(i-1)*16+4];
		temp[i*16+8] = temp[i*16+8] ^ temp[(i-1)*16+8];
		temp[i*16+12] = temp[i*16+12] ^ temp[(i-1)*16+12];
		for(j=1;j<4;j++)
		{
			temp[i*16+j] = temp[i*16+j-1] ^ temp[(i-1)*16+j];
			temp[i*16+j+4] = temp[i*16+j+3] ^ temp[(i-1)*16+j+4];
			temp[i*16+j+8] = temp[i*16+j+7] ^ temp[(i-1)*16+j+8];
			temp[i*16+j+12] = temp[i*16+j+11] ^ temp[(i-1)*16+j+12];
			/*temp[16] = temp[16] ^ temp[0];
			temp[20] = temp[20] ^ temp[4];
			temp[24] = temp[24] ^ temp[8];
			temp[28] = temp[28] ^ temp[12];*/
		}
	}
	//return temp;
}

void InvShiftRows(unsigned char* state) 
{
	unsigned char temp;
	temp = state[7];
	state[7] = state[6];
	state[6] = state[5];
	state[5] = state[4];
	state[4] = temp;
	temp = state[8];
	state[8] = state[10];
	state[10] = temp;
	temp = state[9];
	state[9] = state[11];
	state[11] = temp;
	temp = state[12];
	state[12] = state[13];
	state[13] = state[14];
	state[14] = state[15];
	state[15] = temp;
}

void ShiftRows(unsigned char* state) 
{
	unsigned char temp;
	temp = state[4];
	state[4] = state[5];
	state[5] = state[6];
	state[6] = state[7];
	state[7] = temp;
	temp = state[8];
	state[8] = state[10];
	state[10] = temp;
	temp = state[9];
	state[9] = state[11];
	state[11] = temp;
	temp = state[15];
	state[15] = state[14];
	state[14] = state[13];
	state[13] = state[12];
	state[12] = temp;
}

void SubBytes(unsigned char * state) 
{
	int i;
	for(i=0;i<16;i++)
	{
		state[i] = aes_sbox[state[i]];
	}
}

void MixColumns(unsigned char * state)
{
	unsigned char a[4];
	unsigned char b[4];

	int i;
	for(i=0; i<4; i++) {
		a[0]=state[0+i];
		a[1]=state[4+i];
		a[2]=state[8+i];
		a[3]=state[12+i];
		int j;
		for(j=0;j<4;j++)
		{
			b[j] = a[j] << 1;
			if((a[j] & 0x80) == 0x80)
			{
				b[j] = b[j] ^ 0x1b;
			}
		}
        state[0+i] = b[0] ^ b[1] ^ a[1] ^ a[2] ^ a[3]; // 2 * a0 + a3 + a2 + 3 * a1 
        state[4+i] = a[0] ^ b[1] ^ b[2] ^ a[2] ^ a[3]; // a0 + 2 * a1 + 3 * a2 + a3 
        state[8+i] = a[0] ^ a[1] ^ b[2] ^ b[3] ^ a[3]; // a0 + a1 + 2 * a2 + 3 * a3 
        state[12+i] = b[0] ^ a[0] ^ a[1] ^ a[2] ^ b[3]; // 3 * a0 + a1 + a2 + 2 * a3 
	}
}

void AddRoundKey(unsigned char * state, unsigned char * roundKeys, int n)
{
	int i;
	printf("\nState: ");
	for(i=0;i<16;i++)
	{
		state[i] = state[i] ^ roundKeys[n*16+i];

		printf("%02x", state[i]);
	}
	printf("\n");
}


/** encrypt
 *  Perform AES encryption in software.
 *
 *  Input: msg_ascii - Pointer to 32x 8-bit char array that contains the input message in ASCII format
 *         key_ascii - Pointer to 32x 8-bit char array that contains the input key in ASCII format
 *  Output:  msg_enc - Pointer to 4x 32-bit int array that contains the encrypted message
 *               key - Pointer to 4x 32-bit int array that contains the input key
 */
void encrypt(unsigned char * msg_ascii, unsigned char * key_ascii, unsigned int * msg_enc, unsigned int * key)
{
	// Implement this function
/*	unsigned char state[16];
	unsigned char  state_ptr = & state;
	unsigned char key_input[16];
	unsigned char  key_ptr = & key_input;*/
	//printf("We can print");
	unsigned char * state = malloc(sizeof(unsigned char)*16);
	unsigned char * key_input = malloc(sizeof(unsigned char)*16);
	int i;
	for(i=0;i<32;i+=2)
	{
		state[((i/2)%4)*4+((i/2)/4)] = charsToHex(msg_ascii[i], msg_ascii[i+1]);
		key_input[((i/2)%4)*4+((i/2)/4)] = charsToHex(key_ascii[i], key_ascii[i+1]);
	}
	unsigned char * key_schedule = malloc(sizeof(unsigned char)*176);
	KeyExpansion(key_input, key_schedule);
	for(i=0;i<11;i++)
	{
		printf("\nRound Key: ");
		int j;
		for(j=0;j<16;j++)
		{
			printf("%02x", key_schedule[i*16+j]);
		}
	}
	//printf("\nState: ");
	AddRoundKey(state, key_schedule, 0);
	//int i;
	for(i=1;i<10;i++)
	{
		SubBytes(state);
		ShiftRows(state);
		MixColumns(state);
		AddRoundKey(state, key_schedule, i);
	}
	SubBytes(state);
	ShiftRows(state);
	AddRoundKey(state, key_schedule, 10);
	for(i=0;i<4;i++)
	{
		//msg_enc[i] = (state[i*4] << 12) | (state[i*4+1] << 8) | (state[i*4+2] << 4) | state[i*4+3];
		msg_enc[i] = state[i];
		msg_enc[i] = msg_enc[i] << 8;
		msg_enc[i] = msg_enc[i] | state[i+4];
		msg_enc[i] = msg_enc[i] << 8;
		msg_enc[i] = msg_enc[i] | state[i+8];
		msg_enc[i] = msg_enc[i] << 8;
		msg_enc[i] = msg_enc[i] | state[i+12];

		//key[i] = (key_input[i*4] << 12) | (key_input[i*4+1] << 8) | (key_input[i*4+2] << 4) | key_input[i*4+3];
		key[i] = key_input[i];
		key[i] = key[i] << 8;
		key[i] = key[i] | key_input[i+4];
		key[i] = key[i] << 8;
		key[i] = key[i] | key_input[i+8];
		key[i] = key[i] << 8;
		key[i] = key[i] | key_input[i+12];
		//key[i] = key[i] << 8;

	}
	//AES_PTR = key;
	//printf(key_input);
	//printf(*AES_PTR);

	free(key_schedule);
	free(state);
	free(key_input);
}

/** decrypt
 *  Perform AES decryption in hardware.
 *
 *  Input:  msg_enc - Pointer to 4x 32-bit int array that contains the encrypted message
 *              key - Pointer to 4x 32-bit int array that contains the input key
 *  Output: msg_dec - Pointer to 4x 32-bit int array that contains the decrypted message
 */
void decrypt(unsigned int * msg_enc, unsigned int * msg_dec, unsigned int * key)
{
	// Implement this function
}

/** main
 *  Allows the user to enter the message, key, and select execution mode
 *
 */
int main()
{
	// Input Message and Key as 32x 8-bit ASCII Characters ([33] is for NULL terminator)
	unsigned char msg_ascii[33];
	unsigned char key_ascii[33];
	// Key, Encrypted Message, and Decrypted Message in 4x 32-bit Format to facilitate Read/Write to Hardware
	unsigned int key[4];
	unsigned int msg_enc[4];
	//unsigned int msg_dec[4];

	printf("Select execution mode: 0 for testing, 1 for benchmarking: ");
	scanf("%d", &run_mode);

	if (run_mode == 0) {
		// Continuously Perform Encryption and Decryption
		while (1) {
			int i = 0;
			printf("\nEnter Message:\n");
			scanf("%s", msg_ascii);
			printf("\n");
			printf("\nEnter Key:\n");
			scanf("%s", key_ascii);
			printf("\n");
			encrypt(msg_ascii, key_ascii, msg_enc, key);
			printf("\nEncrypted message is: \n");
			for(i = 0; i < 4; i++){
				printf("%08x", msg_enc[i]);
			}
			printf("\nInput Key is: \n");
			for(i=0;i<4;i++) {
				printf("%08x", key[i]);
			}
			for(i=0;i<8;i++){

			}

			AES_PTR = key;
			printf("\nAES_PTR is: \n");
			for(i=0;i<4;i++) {
			printf("%08x", AES_PTR[i]);
						}
			//AES_PTR = AES_PTR[0,3];

			//printf("\n");
			/*decrypt(msg_enc, msg_dec, key);
			printf("\nDecrypted message is: \n");
			for(i = 0; i < 4; i++){
				printf("%08x", msg_dec[i]);
			}*/
			printf("\n");
		}
	}
	else {
		// Run the Benchmark
		int i = 0;
		int size_KB = 2;
		// Choose a random Plaintext and Key
		for (i = 0; i < 32; i++) {
			msg_ascii[i] = 'a';
			key_ascii[i] = 'b';
		}
		// Run Encryption
		clock_t begin = clock();
		for (i = 0; i < size_KB * 64; i++)
			encrypt(msg_ascii, key_ascii, msg_enc, key);
		clock_t end = clock();
		double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
		double speed = size_KB / time_spent;
		printf("Software Encryption Speed: %f KB/s \n", speed);
		// Run Decryption
		/*begin = clock();
		for (i = 0; i < size_KB * 64; i++)
			decrypt(msg_enc, msg_dec, key);
		end = clock();
		time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
		speed = size_KB / time_spent;*/
		printf("Hardware Encryption Speed: %f KB/s \n", speed);
	}
	return 0;
}
